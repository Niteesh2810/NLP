from flask import Flask, render_template, request
import pickle
import numpy as np
from nltk.tokenize import sent_tokenize
import gensim
from gensim.utils import simple_preprocess
from processing import *


app = Flask(__name__, template_folder='templates')
model = pickle.load(open('finalized_model.h5', 'rb'))


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=["POST"])
def predict():
    review = request.form.get('review')

    review = review.lower()

    review = remove_html_tags(review)

    review = remove_url(review)

    review = remove_punc(review)

    review = remove_chat_words(review)

    review = remove_stopwords(review)

    review = lem_words(review)

    story = []
    for doc in review.split('.'):
        raw_sent = sent_tokenize(doc)
        for sent in raw_sent:
            story.append(simple_preprocess(sent))


    m = gensim.models.Word2Vec(window=2, min_count=1)
    m.build_vocab(story)
    m.train(story, total_examples=m.corpus_count, epochs=m.epochs)

    X = []
    for doc in review.split('.'):
        X.append(document_vector(doc, m))
    X = np.array(X)

    output = model.predict(X)[0]
    print(output)
    if output == 1:
        result = "REVIEW IS POSITIVE"
    else:
        result = "REVIEW IS NEGATIVE"
    return render_template('index.html', result=result)


if __name__ == '__main__':
    app.run(debug=True)
