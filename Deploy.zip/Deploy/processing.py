import re
import string
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import numpy as np

def remove_html_tags(text):
    pattern = re.compile('<.*?>')
    return pattern.sub(r'', text)


def remove_url(text):
    pattern = re.compile(r'https?://S+|www\.\S+')
    return pattern.sub(r'', text)


exclude = string.punctuation


def remove_punc(text):
    return text.translate(str.maketrans('', '', exclude))


chat_words = {
    'AFAIK': 'As Far As I Know', 'AFK': 'Away From Keyboard', 'ASAP': 'As Soon As Possible', 'ATK': 'At The Keyboard',
    'ATM': 'At The Moment', 'BAK': 'Back At Keyboard', 'BBL': 'Be Back Later', 'BBS': 'Be Back Soon',
    'BFN': 'Bye For Now', 'B4N': 'Bye For Now', 'BRB': 'Be Right Back', 'BRT': 'Be Right There', 'BTW': 'By The Way',
    'B4': 'Before', 'B4N': 'Bye For Now', 'CU': 'See You', 'CUL8R': 'See You Later', 'CYA': 'See You',
    'FAQ': 'Frequently Asked Questions', 'FC': 'Fingers Crossed', 'FYI': 'For Your Information', 'GAL': 'Get A Life',
    'GG': 'Good Game', 'GN': 'Good Night', 'GMTA': 'Great Minds Think Alike', 'GR8': 'Great',
    'G9': 'Genius', 'IC': 'I See', 'ICQ': 'I Seek you', 'ILU': 'I Love You', 'IMHO': 'In My Honest Opinion',
    'IMO': 'In My Opinion', 'IOW': 'In Other Words', 'IRL': 'In Real Life', 'LDR': 'Long Distance Relationship',
    'LOL': 'Laughing Out Loud', 'LTNS': 'Long Time No See', 'L8R': 'Later',
    'MTE': 'My Thoughts Exactly', 'M8': 'Mate', 'NRN': 'No Reply Necessary', 'OIC': 'Oh I See',
    'PITA': 'Pain In The Ass', 'PRT': 'Party', 'PRW': 'Parents Are Watching', 'ROFL': 'Rolling On The Floor Laughing',
    'ROFLOL': 'Rolling On The Floor Laughing Out Loud', 'ROTFLMAO': 'Rolling On The Floor Laughing My Ass Off',
    'SK8': 'Skate', 'THX': 'Thank You', 'TTYL': 'Talk To You Later', 'U': 'You', 'U2': 'You Too',
    'U4E': 'Yours For Ever', 'WB': 'Welcome Back', 'WTF': 'What The Fuck', 'WTG': 'Way To Go',
    'WUF': 'Where Are You From', 'W8': 'Wait', 'TFW': 'That feeling when', 'MFW': 'My face when',
    'MRW': 'My reaction when', 'IFYP': 'I feel your pain', 'TNTL': 'Trying not to laugh',
    'JK': 'Just kidding', 'IDC': "I don't care", 'ILY': 'I love you', 'IMU': 'I miss you',
    'ADIH': 'Another day in hell', 'ZZZ': 'Sleeping', 'WYWH': 'Wish you were here', 'BAE': 'Before anyone else',
    'FIMH': 'Forever in my heart', 'BSAAW': 'Big smile and a wink', 'BWL': 'Bursting with laughter',
    'LMAO': 'Laughing my ass off', 'BFF': 'Best friends forever', 'CSL': 'Can’t stop laughing'}


def remove_chat_words(text):
    new_text = []
    for w in text.split():
        if w.upper() in chat_words:
            new_text.append(chat_words[w.upper()].lower())

        else:
            new_text.append(w)
    return " ".join(new_text)


def remove_stopwords(text):
    new_text = []
    for word in text.split():
        if word in stopwords.words('english'):
            new_text.append('')
        else:
            new_text.append(word)
    return " ".join(new_text)


lemmatizer = WordNetLemmatizer()


def lem_words(text):
    new_text = []
    for word in text.split():
        w = lemmatizer.lemmatize(word, pos='v')
        new_text.append(w)

    return " ".join(new_text)


def document_vector(doc, m):
    doc = [word for word in doc.split() if word in m.wv.index_to_key]
    return np.mean(m.wv[doc], axis=0)
